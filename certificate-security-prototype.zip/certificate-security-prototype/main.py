#!/usr/bin/env python3
"""
Certificate Security Prototype – CLI entry point
------------------------------------------------
Industry Stream portfolio artefact demonstrating analysis of
digital-certificate risks (expiry, inventory gaps, weak crypto).

Usage examples:
  python main.py analyse samples/
  python main.py analyse samples/expired.pem --no-register
  python main.py inventory summary
  python main.py inventory expiring --days 60
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import List

import click
import yaml
from rich.console import Console
from rich.logging import RichHandler
from rich.table import Table

from src.analyzer import CertificateAnalyzer
from src.inventory import InventoryManager
from src.models import CertificateInfo
from src.reporter import ReportGenerator

console = Console()


def load_config(config_path: Path) -> dict:
    if not config_path.exists():
        console.print(f"[red]Config file not found: {config_path}[/red]")
        sys.exit(1)
    with config_path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def setup_logging(cfg: dict) -> None:
    level = getattr(logging, cfg.get("logging", {}).get("level", "INFO").upper(), logging.INFO)
    handlers: list = []
    if cfg.get("logging", {}).get("console", True):
        handlers.append(RichHandler(console=console, rich_tracebacks=True))
    log_file = cfg.get("logging", {}).get("file")
    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=handlers,
    )


def collect_certificate_paths(target: Path) -> List[Path]:
    if target.is_file():
        return [target]
    if target.is_dir():
        paths = list(target.glob("*.pem")) + list(target.glob("*.crt")) + list(target.glob("*.cer"))
        return sorted(paths)
    console.print(f"[red]Path does not exist: {target}[/red]")
    sys.exit(1)


@click.group()
@click.option(
    "--config",
    "config_path",
    default="config.yaml",
    type=click.Path(path_type=Path),
    help="Path to YAML configuration file",
)
@click.pass_context
def cli(ctx: click.Context, config_path: Path) -> None:
    """Certificate Security Prototype – analyse expiry, crypto strength and inventory gaps."""
    cfg = load_config(config_path)
    setup_logging(cfg)
    ctx.ensure_object(dict)
    ctx.obj["config"] = cfg


@cli.command()
@click.argument("target", type=click.Path(path_type=Path))
@click.option("--no-register", is_flag=True, help="Do not add certificates to the inventory")
@click.pass_context
def analyse(ctx: click.Context, target: Path, no_register: bool) -> None:
    """Analyse one or more certificate files and produce reports."""
    cfg = ctx.obj["config"]
    analyzer = CertificateAnalyzer(cfg)
    inventory = InventoryManager(cfg.get("inventory", {}).get("path", "samples/inventory.json"))
    auto_register = cfg.get("inventory", {}).get("auto_register", True) and not no_register

    paths = collect_certificate_paths(target)
    if not paths:
        console.print("[yellow]No certificate files found.[/yellow]")
        return

    console.print(f"[bold]Analysing {len(paths)} certificate(s)…[/bold]")
    results: List[CertificateInfo] = []

    for path in paths:
        try:
            info = analyzer.analyse_file(path)
            results.append(info)
            if auto_register:
                inventory.register(info, notes="Auto-registered during analysis")
        except Exception as exc:
            console.print(f"[red]Failed to analyse {path.name}: {exc}[/red]")

    gaps = inventory.find_gaps(results)

    reporter = ReportGenerator(
        output_dir=cfg.get("reporting", {}).get("output_dir", "reports"),
        include_raw_pem=cfg.get("reporting", {}).get("include_raw_pem", False),
    )
    report = reporter.build_report(results, gaps)

    formats = cfg.get("reporting", {}).get("formats", ["json", "markdown"])
    if "json" in formats:
        reporter.write_json(report)
    if "markdown" in formats:
        reporter.write_markdown(report)

    # Pretty console summary
    table = Table(title="Analysis Summary")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")
    for k, v in report.summary.items():
        table.add_row(k.replace("_", " ").title(), str(v))
    console.print(table)

    if gaps:
        console.print("\n[bold red]Inventory Gaps:[/bold red]")
        for g in gaps:
            console.print(f"  • {g}")

    console.print("\n[bold]Top Recommendations:[/bold]")
    for rec in report.recommendations[:5]:
        console.print(f"  → {rec}")

    console.print(f"\n[green]Reports written to {reporter.output_dir}/[/green]")


@cli.group()
def inventory() -> None:
    """Inspect or query the certificate inventory."""
    pass


@inventory.command("summary")
@click.pass_context
def inventory_summary(ctx: click.Context) -> None:
    """Show a high-level inventory summary."""
    cfg = ctx.obj["config"]
    inv = InventoryManager(cfg.get("inventory", {}).get("path", "samples/inventory.json"))
    summary = inv.summary()
    console.print(f"[bold]Inventory contains {summary['total_entries']} entries[/bold]")
    console.print(f"Unique subjects: {summary['unique_subjects']}")


@inventory.command("expiring")
@click.option("--days", default=30, show_default=True, help="Look-ahead window in days")
@click.pass_context
def inventory_expiring(ctx: click.Context, days: int) -> None:
    """List inventory entries that expire within N days."""
    cfg = ctx.obj["config"]
    inv = InventoryManager(cfg.get("inventory", {}).get("path", "samples/inventory.json"))
    entries = inv.list_expiring_soon(within_days=days)

    if not entries:
        console.print(f"[green]No certificates expiring within {days} days.[/green]")
        return

    table = Table(title=f"Certificates expiring within {days} days")
    table.add_column("Subject")
    table.add_column("Not After")
    table.add_column("Source")
    for e in entries:
        table.add_row(e.subject, e.not_after, e.source)
    console.print(table)


if __name__ == "__main__":
    cli()
