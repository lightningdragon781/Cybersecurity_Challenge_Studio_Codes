# Certificate Security Analysis Report

**Generated:** 2026-09-13T03:49:05.865130+00:00
**Certificates analysed:** 5

## Summary

| Metric | Count |
|--------|-------|
| Valid | 2 |
| Expired | 1 |
| Near Expiry | 1 |
| Weak Crypto | 1 |
| Not Yet Valid | 0 |
| Critical Findings | 1 |
| High Findings | 2 |

## Certificate Details

### 1. CN=legacy.expired.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU

- **Status:** `EXPIRED`
- **Risk Score:** 55/100
- **Issuer:** CN=legacy.expired.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU
- **Serial:** `32ea2a51ef20bb35492656c13c0ec1b1094ed889`
- **Validity:** 2026-07-15 → 2026-08-14 (-30.0 days remaining)
- **Signature Algorithm:** sha256WithRSAEncryption
- **Public Key:** RSA (2048 bits)
- **Fingerprints:**
  - SHA256: `ec9a721b0aa4cf6c5d3d2211e34ab51b8aee13d1af669d71de98eca1eccb3670`
  - SHA1: `dbe52118286ab8f2defc42c86ba3a4e6161ddd3b`
- **SANs:** <DNSName(value='legacy.expired.local')>
- **Findings:**
  - **[CRITICAL]** (expiry) Certificate has expired  
    → *Recommendation:* Immediately renew or replace the certificate to restore service.
  - **[MEDIUM]** (trust) Certificate appears to be self-signed  
    → *Recommendation:* Verify whether a self-signed certificate is intentional for this use-case.

### 2. CN=api.near-expiry.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU

- **Status:** `NEAR_EXPIRY`
- **Risk Score:** 40/100
- **Issuer:** CN=api.near-expiry.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU
- **Serial:** `4c00b33f6f7f65ce20432c14d49cb9cfbf2123c8`
- **Validity:** 2026-09-13 → 2026-09-25 (12.0 days remaining)
- **Signature Algorithm:** sha256WithRSAEncryption
- **Public Key:** RSA (2048 bits)
- **Fingerprints:**
  - SHA256: `f4da4be2733e255f5df620c2279cae51a0a3dd35a0d9df6e22cce866548b0fcf`
  - SHA1: `d03f3f77bdc540f48a18186e552a3365770fc676`
- **SANs:** <DNSName(value='api.near-expiry.local')>
- **Findings:**
  - **[HIGH]** (expiry) Certificate expires in 12.0 days  
    → *Recommendation:* Schedule renewal within the next few days.
  - **[MEDIUM]** (trust) Certificate appears to be self-signed  
    → *Recommendation:* Verify whether a self-signed certificate is intentional for this use-case.

### 3. CN=selfsigned.no-san.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU

- **Status:** `VALID`
- **Risk Score:** 30/100
- **Issuer:** CN=selfsigned.no-san.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU
- **Serial:** `5a61604454f138cc411bedb86cc37226ba86d72a`
- **Validity:** 2026-09-13 → 2027-03-12 (180.0 days remaining)
- **Signature Algorithm:** sha256WithRSAEncryption
- **Public Key:** RSA (2048 bits)
- **Fingerprints:**
  - SHA256: `b89987839c57de040f418a708856f3e489a4a1c5346367eee841375cf71e3a11`
  - SHA1: `1df7b76510e37028afe7b6c7b07ddfb69325a1ae`
- **Findings:**
  - **[MEDIUM]** (trust) Certificate appears to be self-signed  
    → *Recommendation:* Verify whether a self-signed certificate is intentional for this use-case.
  - **[MEDIUM]** (compliance) No Subject Alternative Names (SANs) present  
    → *Recommendation:* Modern TLS clients expect SANs; consider re-issuing with appropriate DNS/IP SANs.

### 4. CN=app.valid-demo.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU

- **Status:** `VALID`
- **Risk Score:** 15/100
- **Issuer:** CN=app.valid-demo.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU
- **Serial:** `1ec4af7ff026f33ec2bd539d065ae80f4d706693`
- **Validity:** 2026-09-13 → 2027-09-13 (365.0 days remaining)
- **Signature Algorithm:** sha256WithRSAEncryption
- **Public Key:** RSA (2048 bits)
- **Fingerprints:**
  - SHA256: `22ba165f0a5aec13438f0f076822afcaf17a16819b8fea143e2385457263e5a7`
  - SHA1: `9f2a04e824c03bb7b1e33a2487ba38182efb6fce`
- **SANs:** <DNSName(value='app.valid-demo.local')>
- **Findings:**
  - **[MEDIUM]** (trust) Certificate appears to be self-signed  
    → *Recommendation:* Verify whether a self-signed certificate is intentional for this use-case.

### 5. CN=old.weak-crypto.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU

- **Status:** `WEAK_CRYPTO`
- **Risk Score:** 40/100
- **Issuer:** CN=old.weak-crypto.local,O=UTS Challenge Studio Demo,ST=NSW,C=AU
- **Serial:** `d32907de19a1a284574dddfcec9d7248ce351c4`
- **Validity:** 2026-09-13 → 2026-12-12 (90.0 days remaining)
- **Signature Algorithm:** sha256WithRSAEncryption
- **Public Key:** RSA (1024 bits)
- **Fingerprints:**
  - SHA256: `79cdb6fd4b797da1a1805642c8237be3b6859a8cd56364c55f31e5b503b1aa2e`
  - SHA1: `68819717580cbd378a7f48eb778e9aa75f13aced`
- **SANs:** <DNSName(value='old.weak-crypto.local')>
- **Findings:**
  - **[HIGH]** (cryptography) Public key size (1024 bits) is below minimum (2048)  
    → *Recommendation:* Replace with a certificate using a stronger key.
  - **[MEDIUM]** (trust) Certificate appears to be self-signed  
    → *Recommendation:* Verify whether a self-signed certificate is intentional for this use-case.

## Overall Recommendations

1. 1 certificate(s) have already expired. Immediate replacement is required to avoid service outages.
2. 1 certificate(s) are approaching expiry. Implement automated renewal or a clear calendar reminder process.
3. Weak cryptographic parameters detected. Re-issue affected certificates with modern algorithms and adequate key sizes.

---
*Generated by Certificate Security Prototype – Industry Stream Portfolio*