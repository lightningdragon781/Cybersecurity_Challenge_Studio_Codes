"""
Domain models and data structures used across the prototype.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


class RiskLevel(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class CertificateStatus(str, Enum):
    VALID = "VALID"
    EXPIRED = "EXPIRED"
    NOT_YET_VALID = "NOT_YET_VALID"
    NEAR_EXPIRY = "NEAR_EXPIRY"
    WEAK_CRYPTO = "WEAK_CRYPTO"
    UNKNOWN = "UNKNOWN"


@dataclass
class Fingerprint:
    algorithm: str
    value: str

    def to_dict(self) -> Dict[str, str]:
        return {"algorithm": self.algorithm, "value": self.value}


@dataclass
class ValidityWindow:
    not_before: datetime
    not_after: datetime

    @property
    def is_expired(self) -> bool:
        return datetime.now(timezone.utc) > self.not_after

    @property
    def is_not_yet_valid(self) -> bool:
        return datetime.now(timezone.utc) < self.not_before

    def days_until_expiry(self) -> float:
        delta = self.not_after - datetime.now(timezone.utc)
        return delta.total_seconds() / 86400.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "not_before": self.not_before.isoformat(),
            "not_after": self.not_after.isoformat(),
            "days_until_expiry": round(self.days_until_expiry(), 2),
            "is_expired": self.is_expired,
            "is_not_yet_valid": self.is_not_yet_valid,
        }


@dataclass
class RiskFinding:
    level: RiskLevel
    category: str
    message: str
    recommendation: str
    evidence: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "level": self.level.value,
            "category": self.category,
            "message": self.message,
            "recommendation": self.recommendation,
            "evidence": self.evidence,
        }


@dataclass
class CertificateInfo:
    """Rich representation of a parsed X.509 certificate."""

    subject: str
    issuer: str
    serial_number: str
    version: int
    signature_algorithm: str
    public_key_algorithm: str
    public_key_size: Optional[int]
    validity: ValidityWindow
    fingerprints: List[Fingerprint] = field(default_factory=list)
    subject_alternative_names: List[str] = field(default_factory=list)
    extensions: Dict[str, Any] = field(default_factory=dict)
    status: CertificateStatus = CertificateStatus.UNKNOWN
    risk_findings: List[RiskFinding] = field(default_factory=list)
    risk_score: int = 0  # 0–100 (higher = more risk)
    source_path: Optional[str] = None
    raw_pem: Optional[str] = None

    def add_finding(self, finding: RiskFinding) -> None:
        self.risk_findings.append(finding)
        # Simple scoring: Critical=40, High=25, Medium=15, Low=5
        weights = {
            RiskLevel.CRITICAL: 40,
            RiskLevel.HIGH: 25,
            RiskLevel.MEDIUM: 15,
            RiskLevel.LOW: 5,
            RiskLevel.INFO: 0,
        }
        self.risk_score = min(100, self.risk_score + weights.get(finding.level, 0))

    def to_dict(self, include_raw: bool = False) -> Dict[str, Any]:
        data = {
            "subject": self.subject,
            "issuer": self.issuer,
            "serial_number": self.serial_number,
            "version": self.version,
            "signature_algorithm": self.signature_algorithm,
            "public_key_algorithm": self.public_key_algorithm,
            "public_key_size": self.public_key_size,
            "validity": self.validity.to_dict(),
            "fingerprints": [fp.to_dict() for fp in self.fingerprints],
            "subject_alternative_names": self.subject_alternative_names,
            "extensions": self.extensions,
            "status": self.status.value,
            "risk_score": self.risk_score,
            "risk_findings": [f.to_dict() for f in self.risk_findings],
            "source_path": self.source_path,
        }
        if include_raw and self.raw_pem:
            data["raw_pem"] = self.raw_pem
        return data


@dataclass
class InventoryEntry:
    """A single record in the simulated certificate inventory."""

    fingerprint_sha256: str
    subject: str
    issuer: str
    not_after: str
    source: str
    last_seen: str
    notes: str = ""
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AnalysisReport:
    """Top-level report produced by a full analysis run."""

    generated_at: str
    total_certificates: int
    summary: Dict[str, int]
    certificates: List[CertificateInfo]
    inventory_gaps: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)

    def to_dict(self, include_raw: bool = False) -> Dict[str, Any]:
        return {
            "generated_at": self.generated_at,
            "total_certificates": self.total_certificates,
            "summary": self.summary,
            "certificates": [c.to_dict(include_raw=include_raw) for c in self.certificates],
            "inventory_gaps": self.inventory_gaps,
            "recommendations": self.recommendations,
        }
