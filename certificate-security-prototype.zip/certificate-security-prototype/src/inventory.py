"""
Simple certificate inventory manager.
Simulates the organisational problem of missing centralised inventories
by maintaining a lightweight JSON-based registry of known certificates.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from .models import CertificateInfo, InventoryEntry

logger = logging.getLogger(__name__)


class InventoryManager:
    """Load, query and update a JSON-backed certificate inventory."""

    def __init__(self, inventory_path: str | Path):
        self.path = Path(inventory_path)
        self.entries: Dict[str, InventoryEntry] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            logger.info("Inventory file %s does not exist – starting empty", self.path)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._save()
            return

        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            for item in raw.get("certificates", []):
                entry = InventoryEntry(**item)
                self.entries[entry.fingerprint_sha256] = entry
            logger.info("Loaded %d entries from inventory", len(self.entries))
        except Exception as exc:
            logger.error("Failed to load inventory: %s", exc)
            self.entries = {}

    def _save(self) -> None:
        payload = {
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "count": len(self.entries),
            "certificates": [e.to_dict() for e in self.entries.values()],
        }
        self.path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        logger.debug("Inventory saved (%d entries)", len(self.entries))

    def get(self, sha256: str) -> Optional[InventoryEntry]:
        return self.entries.get(sha256.lower())

    def contains(self, sha256: str) -> bool:
        return sha256.lower() in self.entries

    def register(self, info: CertificateInfo, notes: str = "", tags: Optional[List[str]] = None) -> None:
        """Add or update a certificate in the inventory using its SHA-256 fingerprint."""
        sha256 = None
        for fp in info.fingerprints:
            if fp.algorithm.lower() == "sha256":
                sha256 = fp.value.lower()
                break
        if not sha256:
            logger.warning("Cannot register certificate without SHA-256 fingerprint")
            return

        entry = InventoryEntry(
            fingerprint_sha256=sha256,
            subject=info.subject,
            issuer=info.issuer,
            not_after=info.validity.not_after.isoformat(),
            source=info.source_path or "unknown",
            last_seen=datetime.now(timezone.utc).isoformat(),
            notes=notes,
            tags=tags or [],
        )
        self.entries[sha256] = entry
        self._save()
        logger.info("Registered/updated inventory entry for %s", info.subject)

    def find_gaps(self, analysed: List[CertificateInfo]) -> List[str]:
        """
        Identify certificates that were analysed but are missing from the inventory.
        This highlights the classic organisational inventory gap.
        """
        gaps = []
        for info in analysed:
            sha256 = next(
                (fp.value.lower() for fp in info.fingerprints if fp.algorithm.lower() == "sha256"),
                None,
            )
            if sha256 and not self.contains(sha256):
                gaps.append(
                    f"Missing from inventory: {info.subject} "
                    f"(SHA-256={sha256[:16]}… source={info.source_path})"
                )
        return gaps

    def list_expiring_soon(self, within_days: int = 30) -> List[InventoryEntry]:
        """Return inventory entries that expire within the given number of days."""
        now = datetime.now(timezone.utc)
        result = []
        for entry in self.entries.values():
            try:
                not_after = datetime.fromisoformat(entry.not_after.replace("Z", "+00:00"))
                days_left = (not_after - now).total_seconds() / 86400.0
                if 0 <= days_left <= within_days:
                    result.append(entry)
            except Exception:
                continue
        return result

    def summary(self) -> Dict[str, int]:
        return {
            "total_entries": len(self.entries),
            "unique_subjects": len({e.subject for e in self.entries.values()}),
        }
