"""
Cryptographic helper functions: hashing, fingerprinting, key inspection.
"""

from __future__ import annotations

import hashlib
from typing import List, Optional, Tuple

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import dsa, ec, ed25519, rsa

from .models import Fingerprint


def compute_fingerprint(data: bytes, algorithm: str = "sha256") -> str:
    """Return hex digest of the given data using the requested algorithm."""
    algo = algorithm.lower()
    if algo == "sha256":
        return hashlib.sha256(data).hexdigest()
    if algo == "sha1":
        return hashlib.sha1(data).hexdigest()
    if algo == "md5":
        return hashlib.md5(data).hexdigest()
    raise ValueError(f"Unsupported hash algorithm: {algorithm}")


def certificate_fingerprints(
    cert: x509.Certificate, algorithms: List[str]
) -> List[Fingerprint]:
    """Compute multiple fingerprints over the DER encoding of the certificate."""
    der = cert.public_bytes(serialization.Encoding.DER)
    results = []
    for algo in algorithms:
        try:
            value = compute_fingerprint(der, algo)
            results.append(Fingerprint(algorithm=algo, value=value))
        except ValueError:
            continue
    return results


def get_public_key_info(cert: x509.Certificate) -> Tuple[str, Optional[int]]:
    """
    Return (algorithm_name, key_size_in_bits).
    key_size may be None for algorithms where it is not meaningful.
    """
    public_key = cert.public_key()

    if isinstance(public_key, rsa.RSAPublicKey):
        return "RSA", public_key.key_size
    if isinstance(public_key, dsa.DSAPublicKey):
        return "DSA", public_key.key_size
    if isinstance(public_key, ec.EllipticCurvePublicKey):
        return f"EC-{public_key.curve.name}", public_key.key_size
    if isinstance(public_key, ed25519.Ed25519PublicKey):
        return "Ed25519", 256
    return type(public_key).__name__, None


def signature_algorithm_name(cert: x509.Certificate) -> str:
    """Human-readable signature algorithm string."""
    try:
        return cert.signature_algorithm_oid._name  # type: ignore[attr-defined]
    except Exception:
        return str(cert.signature_hash_algorithm)


def load_pem_certificate(pem_data: bytes) -> x509.Certificate:
    """Load a single PEM-encoded certificate."""
    return x509.load_pem_x509_certificate(pem_data)


def load_der_certificate(der_data: bytes) -> x509.Certificate:
    """Load a single DER-encoded certificate."""
    return x509.load_der_x509_certificate(der_data)


def certificate_to_pem(cert: x509.Certificate) -> str:
    """Return the PEM string representation of a certificate."""
    return cert.public_bytes(serialization.Encoding.PEM).decode("utf-8")
