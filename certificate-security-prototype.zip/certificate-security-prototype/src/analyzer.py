"""
Core certificate analysis engine.
Performs validity checks, risk scoring, weak-crypto detection and status assignment.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from cryptography import x509
from cryptography.x509.oid import ExtensionOID, NameOID

from .crypto_utils import (
    certificate_fingerprints,
    certificate_to_pem,
    get_public_key_info,
    load_der_certificate,
    load_pem_certificate,
    signature_algorithm_name,
)
from .models import (
    CertificateInfo,
    CertificateStatus,
    RiskFinding,
    RiskLevel,
    ValidityWindow,
)

logger = logging.getLogger(__name__)


class CertificateAnalyzer:
    """Analyse one or more X.509 certificates and produce rich CertificateInfo objects."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.near_expiry_days = config.get("analysis", {}).get("near_expiry_days", 30)
        self.critical_expiry_days = config.get("analysis", {}).get("critical_expiry_days", 7)
        self.min_key_size = config.get("analysis", {}).get("min_key_size", 2048)
        self.weak_sig_algos = set(
            a.lower() for a in config.get("analysis", {}).get("weak_signature_algorithms", [])
        )
        self.fingerprint_algos = config.get("crypto", {}).get(
            "fingerprint_algorithms", ["sha256", "sha1"]
        )

    def analyse_file(self, path: Path) -> CertificateInfo:
        """Load a certificate from disk (PEM or DER) and analyse it."""
        data = path.read_bytes()
        try:
            if b"-----BEGIN CERTIFICATE-----" in data:
                cert = load_pem_certificate(data)
            else:
                cert = load_der_certificate(data)
        except Exception as exc:
            logger.error("Failed to parse certificate %s: %s", path, exc)
            raise

        info = self._build_info(cert, source_path=str(path))
        self._apply_risk_rules(info)
        return info

    def analyse_pem(self, pem_data: str, source: str = "<memory>") -> CertificateInfo:
        """Analyse a certificate supplied as a PEM string."""
        cert = load_pem_certificate(pem_data.encode("utf-8"))
        info = self._build_info(cert, source_path=source)
        self._apply_risk_rules(info)
        return info

    def _build_info(self, cert: x509.Certificate, source_path: Optional[str] = None) -> CertificateInfo:
        subject = self._format_name(cert.subject)
        issuer = self._format_name(cert.issuer)
        serial = format(cert.serial_number, "x")
        version = cert.version.value + 1  # cryptography uses 0-based

        sig_algo = signature_algorithm_name(cert)
        key_algo, key_size = get_public_key_info(cert)

        # Compatibility with both older and newer cryptography versions
        not_before = getattr(cert, "not_valid_before_utc", None) or cert.not_valid_before
        not_after = getattr(cert, "not_valid_after_utc", None) or cert.not_valid_after
        if not_before.tzinfo is None:
            not_before = not_before.replace(tzinfo=timezone.utc)
        if not_after.tzinfo is None:
            not_after = not_after.replace(tzinfo=timezone.utc)

        validity = ValidityWindow(
            not_before=not_before,
            not_after=not_after,
        )

        fingerprints = certificate_fingerprints(cert, self.fingerprint_algos)

        sans = self._extract_sans(cert)
        extensions = self._extract_selected_extensions(cert)

        info = CertificateInfo(
            subject=subject,
            issuer=issuer,
            serial_number=serial,
            version=version,
            signature_algorithm=sig_algo,
            public_key_algorithm=key_algo,
            public_key_size=key_size,
            validity=validity,
            fingerprints=fingerprints,
            subject_alternative_names=sans,
            extensions=extensions,
            source_path=source_path,
            raw_pem=certificate_to_pem(cert),
        )
        return info

    def _apply_risk_rules(self, info: CertificateInfo) -> None:
        """Populate status, findings and risk_score based on configured rules."""
        now = datetime.now(timezone.utc)
        days_left = info.validity.days_until_expiry()

        # --- Validity / Expiry ---
        if info.validity.is_not_yet_valid:
            info.status = CertificateStatus.NOT_YET_VALID
            info.add_finding(
                RiskFinding(
                    level=RiskLevel.HIGH,
                    category="validity",
                    message="Certificate is not yet valid",
                    recommendation="Do not deploy until the notBefore date is reached.",
                    evidence=f"notBefore={info.validity.not_before.isoformat()}",
                )
            )
        elif info.validity.is_expired:
            info.status = CertificateStatus.EXPIRED
            info.add_finding(
                RiskFinding(
                    level=RiskLevel.CRITICAL,
                    category="expiry",
                    message="Certificate has expired",
                    recommendation="Immediately renew or replace the certificate to restore service.",
                    evidence=f"notAfter={info.validity.not_after.isoformat()}",
                )
            )
        elif days_left <= self.critical_expiry_days:
            info.status = CertificateStatus.NEAR_EXPIRY
            info.add_finding(
                RiskFinding(
                    level=RiskLevel.CRITICAL,
                    category="expiry",
                    message=f"Certificate expires in {days_left:.1f} days (critical threshold)",
                    recommendation="Prioritise renewal immediately; outage risk is high.",
                    evidence=f"days_remaining={days_left:.1f}",
                )
            )
        elif days_left <= self.near_expiry_days:
            info.status = CertificateStatus.NEAR_EXPIRY
            info.add_finding(
                RiskFinding(
                    level=RiskLevel.HIGH,
                    category="expiry",
                    message=f"Certificate expires in {days_left:.1f} days",
                    recommendation="Schedule renewal within the next few days.",
                    evidence=f"days_remaining={days_left:.1f}",
                )
            )
        else:
            info.status = CertificateStatus.VALID

        # --- Weak signature algorithm ---
        if info.signature_algorithm.lower() in self.weak_sig_algos:
            info.add_finding(
                RiskFinding(
                    level=RiskLevel.HIGH,
                    category="cryptography",
                    message=f"Weak signature algorithm detected: {info.signature_algorithm}",
                    recommendation="Re-issue the certificate using SHA-256 or stronger.",
                    evidence=info.signature_algorithm,
                )
            )
            if info.status == CertificateStatus.VALID:
                info.status = CertificateStatus.WEAK_CRYPTO

        # --- Key size ---
        if info.public_key_size is not None and info.public_key_size < self.min_key_size:
            info.add_finding(
                RiskFinding(
                    level=RiskLevel.HIGH,
                    category="cryptography",
                    message=f"Public key size ({info.public_key_size} bits) is below minimum ({self.min_key_size})",
                    recommendation="Replace with a certificate using a stronger key.",
                    evidence=f"key_size={info.public_key_size}",
                )
            )
            if info.status == CertificateStatus.VALID:
                info.status = CertificateStatus.WEAK_CRYPTO

        # --- Self-signed heuristic (issuer == subject) ---
        if info.subject == info.issuer:
            info.add_finding(
                RiskFinding(
                    level=RiskLevel.MEDIUM,
                    category="trust",
                    message="Certificate appears to be self-signed",
                    recommendation="Verify whether a self-signed certificate is intentional for this use-case.",
                    evidence="subject == issuer",
                )
            )

        # --- Missing SANs (modern browsers require them) ---
        if not info.subject_alternative_names:
            info.add_finding(
                RiskFinding(
                    level=RiskLevel.MEDIUM,
                    category="compliance",
                    message="No Subject Alternative Names (SANs) present",
                    recommendation="Modern TLS clients expect SANs; consider re-issuing with appropriate DNS/IP SANs.",
                )
            )

        logger.info(
            "Analysed %s → status=%s risk_score=%d findings=%d",
            info.subject,
            info.status.value,
            info.risk_score,
            len(info.risk_findings),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _format_name(name: x509.Name) -> str:
        """Produce a readable RFC-4514 style string."""
        try:
            return name.rfc4514_string()
        except Exception:
            parts = []
            for attr in name:
                parts.append(f"{attr.oid._name}={attr.value}")  # type: ignore
            return ", ".join(parts)

    @staticmethod
    def _extract_sans(cert: x509.Certificate) -> List[str]:
        try:
            ext = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
            return [str(name) for name in ext.value]  # type: ignore
        except x509.ExtensionNotFound:
            return []

    @staticmethod
    def _extract_selected_extensions(cert: x509.Certificate) -> Dict[str, Any]:
        """Extract a few commonly interesting extensions in a serialisable form."""
        result: Dict[str, Any] = {}
        interesting = {
            ExtensionOID.BASIC_CONSTRAINTS: "basic_constraints",
            ExtensionOID.KEY_USAGE: "key_usage",
            ExtensionOID.EXTENDED_KEY_USAGE: "extended_key_usage",
            ExtensionOID.AUTHORITY_KEY_IDENTIFIER: "authority_key_identifier",
            ExtensionOID.SUBJECT_KEY_IDENTIFIER: "subject_key_identifier",
        }
        for oid, label in interesting.items():
            try:
                ext = cert.extensions.get_extension_for_oid(oid)
                result[label] = str(ext.value)
            except x509.ExtensionNotFound:
                continue
        return result
