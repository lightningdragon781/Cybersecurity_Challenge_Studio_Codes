"""
Report generation: JSON and Markdown outputs suitable for a student portfolio.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from .models import AnalysisReport, CertificateInfo, RiskLevel

logger = logging.getLogger(__name__)


class ReportGenerator:
    def __init__(self, output_dir: str | Path, include_raw_pem: bool = False):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.include_raw_pem = include_raw_pem

    def build_report(
        self,
        certificates: List[CertificateInfo],
        inventory_gaps: List[str],
        extra_recommendations: List[str] | None = None,
    ) -> AnalysisReport:
        summary = {
            "valid": 0,
            "expired": 0,
            "near_expiry": 0,
            "weak_crypto": 0,
            "not_yet_valid": 0,
            "critical_findings": 0,
            "high_findings": 0,
        }
        for cert in certificates:
            status = cert.status.value.lower()
            if status in summary:
                summary[status] += 1
            for finding in cert.risk_findings:
                if finding.level == RiskLevel.CRITICAL:
                    summary["critical_findings"] += 1
                elif finding.level == RiskLevel.HIGH:
                    summary["high_findings"] += 1

        recommendations = list(extra_recommendations or [])
        recommendations.extend(self._derive_recommendations(certificates, inventory_gaps))

        return AnalysisReport(
            generated_at=datetime.now(timezone.utc).isoformat(),
            total_certificates=len(certificates),
            summary=summary,
            certificates=certificates,
            inventory_gaps=inventory_gaps,
            recommendations=recommendations,
        )

    def write_json(self, report: AnalysisReport, filename: str = "analysis_report.json") -> Path:
        path = self.output_dir / filename
        data = report.to_dict(include_raw=self.include_raw_pem)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        logger.info("JSON report written to %s", path)
        return path

    def write_markdown(self, report: AnalysisReport, filename: str = "analysis_report.md") -> Path:
        path = self.output_dir / filename
        md = self._render_markdown(report)
        path.write_text(md, encoding="utf-8")
        logger.info("Markdown report written to %s", path)
        return path

    def _render_markdown(self, report: AnalysisReport) -> str:
        lines: List[str] = []
        lines.append("# Certificate Security Analysis Report")
        lines.append("")
        lines.append(f"**Generated:** {report.generated_at}")
        lines.append(f"**Certificates analysed:** {report.total_certificates}")
        lines.append("")
        lines.append("## Summary")
        lines.append("")
        lines.append("| Metric | Count |")
        lines.append("|--------|-------|")
        for key, value in report.summary.items():
            lines.append(f"| {key.replace('_', ' ').title()} | {value} |")
        lines.append("")

        if report.inventory_gaps:
            lines.append("## Inventory Gaps Detected")
            lines.append("")
            lines.append(
                "The following certificates were analysed but are **not present** "
                "in the central inventory. This illustrates a common organisational risk."
            )
            lines.append("")
            for gap in report.inventory_gaps:
                lines.append(f"- {gap}")
            lines.append("")

        lines.append("## Certificate Details")
        lines.append("")
        for idx, cert in enumerate(report.certificates, 1):
            lines.append(f"### {idx}. {cert.subject}")
            lines.append("")
            lines.append(f"- **Status:** `{cert.status.value}`")
            lines.append(f"- **Risk Score:** {cert.risk_score}/100")
            lines.append(f"- **Issuer:** {cert.issuer}")
            lines.append(f"- **Serial:** `{cert.serial_number}`")
            lines.append(
                f"- **Validity:** {cert.validity.not_before.date()} → {cert.validity.not_after.date()} "
                f"({cert.validity.days_until_expiry():.1f} days remaining)"
            )
            lines.append(f"- **Signature Algorithm:** {cert.signature_algorithm}")
            lines.append(
                f"- **Public Key:** {cert.public_key_algorithm} "
                f"({cert.public_key_size or 'n/a'} bits)"
            )
            if cert.fingerprints:
                lines.append("- **Fingerprints:**")
                for fp in cert.fingerprints:
                    lines.append(f"  - {fp.algorithm.upper()}: `{fp.value}`")
            if cert.subject_alternative_names:
                lines.append(f"- **SANs:** {', '.join(cert.subject_alternative_names)}")
            if cert.risk_findings:
                lines.append("- **Findings:**")
                for f in cert.risk_findings:
                    lines.append(
                        f"  - **[{f.level.value}]** ({f.category}) {f.message}  \n"
                        f"    → *Recommendation:* {f.recommendation}"
                    )
            lines.append("")

        if report.recommendations:
            lines.append("## Overall Recommendations")
            lines.append("")
            for i, rec in enumerate(report.recommendations, 1):
                lines.append(f"{i}. {rec}")
            lines.append("")

        lines.append("---")
        lines.append("*Generated by Certificate Security Prototype – Industry Stream Portfolio*")
        return "\n".join(lines)

    @staticmethod
    def _derive_recommendations(
        certificates: List[CertificateInfo], gaps: List[str]
    ) -> List[str]:
        recs = []
        expired = sum(1 for c in certificates if c.status.value == "EXPIRED")
        near = sum(1 for c in certificates if c.status.value == "NEAR_EXPIRY")
        weak = sum(1 for c in certificates if c.status.value == "WEAK_CRYPTO")

        if expired:
            recs.append(
                f"{expired} certificate(s) have already expired. "
                "Immediate replacement is required to avoid service outages."
            )
        if near:
            recs.append(
                f"{near} certificate(s) are approaching expiry. "
                "Implement automated renewal or a clear calendar reminder process."
            )
        if weak:
            recs.append(
                "Weak cryptographic parameters detected. "
                "Re-issue affected certificates with modern algorithms and adequate key sizes."
            )
        if gaps:
            recs.append(
                f"{len(gaps)} certificate(s) are missing from the central inventory. "
                "Establish a mandatory registration step whenever a new certificate is issued or installed."
            )
        if not recs:
            recs.append("No critical issues found in the current sample set. Continue regular monitoring.")
        return recs
