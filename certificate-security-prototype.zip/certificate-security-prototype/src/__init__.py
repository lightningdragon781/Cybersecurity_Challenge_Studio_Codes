"""
Certificate Security Prototype
------------------------------
A multi-module educational tool for analysing digital certificate risks,
focusing on expiry, inventory gaps, weak cryptography and basic integrity checks.
"""

__version__ = "0.1.0"
__author__ = "Abhijat Mishra"
