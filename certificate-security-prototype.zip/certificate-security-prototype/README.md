# Certificate Security Prototype

**Industry Stream – Challenge Studio Portfolio Artefact**

A multi-module Python prototype that investigates critical security gaps in digital certificates (PKI), with particular focus on:

- Sudden service outages caused by **expired certificates**
- Organisational risk from **missing centralised inventories**
- Detection of **weak cryptographic parameters**
- Practical, reproducible analysis suitable for a student portfolio

## Features

- Parse PEM/DER X.509 certificates
- Extract rich metadata (subject, issuer, SANs, key size, signature algorithm, fingerprints)
- Configurable risk engine (near-expiry windows, minimum key size, weak algorithms)
- Risk scoring and structured findings with recommendations
- Lightweight JSON-based **certificate inventory** that surfaces gaps
- JSON + Markdown report generation ready for portfolio evidence
- Clean CLI with Rich console output
- Fully reproducible sample certificates for demonstration

## Project Structure

```
certificate-security-prototype/
├── config.yaml                 # All thresholds and paths (no hard-coding)
├── main.py                     # CLI entry point
├── requirements.txt
├── README.md
├── src/
│   ├── __init__.py
│   ├── models.py               # Dataclasses & enums
│   ├── crypto_utils.py         # Hashing, fingerprinting, key inspection
│   ├── analyzer.py             # Core risk analysis engine
│   ├── inventory.py            # Simulated central inventory
│   └── reporter.py             # JSON / Markdown report writers
├── scripts/
│   └── generate_sample_certs.py
├── samples/                    # Generated test certificates + inventory
└── reports/                    # Analysis output (created at runtime)
```

## Quick Start

```bash
# 1. Create a virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Generate realistic sample certificates
python scripts/generate_sample_certs.py

# 4. Run a full analysis on the sample set
python main.py analyse samples/

# 5. Inspect the inventory
python main.py inventory summary
python main.py inventory expiring --days 30
```

Reports appear in the `reports/` directory (`analysis_report.json` and `analysis_report.md`).

## Configuration

All behaviour is driven by `config.yaml`:

- Near-expiry / critical-expiry thresholds
- Minimum acceptable key size
- List of weak signature algorithms
- Inventory path and auto-registration
- Report formats and logging

## Ethical Scope

This prototype is intentionally limited to:

- Locally generated sample certificates
- Publicly available or lab-provided certificate files
- Analysis only (no active scanning of live third-party systems)

It does **not** perform unauthorised network access or production-scale certificate management.

## Portfolio Evidence

Recommended artefacts to include:

1. This repository (or selected source files)
2. Generated Markdown/JSON reports
3. Screenshots of CLI output and inventory gap detection
4. Short explanation of how the prototype addresses the two core problems (expiry outages + inventory gaps)
5. AI-use disclosure (if any assistance was used while developing the code)

## Author

Abhijat Mishra – UTS Challenge Studio (Industry Stream)
