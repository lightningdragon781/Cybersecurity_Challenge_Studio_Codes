#!/usr/bin/env python3
"""
Generate a realistic set of sample certificates for demonstration:
- A valid long-lived certificate
- A near-expiry certificate
- An already-expired certificate
- A weak (SHA-1 / small key) certificate
- A self-signed certificate

These are purely for local testing and portfolio evidence.
"""

from __future__ import annotations

import datetime as dt
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID


SAMPLES_DIR = Path(__file__).resolve().parent.parent / "samples"
SAMPLES_DIR.mkdir(parents=True, exist_ok=True)


def _build_name(common_name: str) -> x509.Name:
    return x509.Name(
        [
            x509.NameAttribute(NameOID.COUNTRY_NAME, "AU"),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "NSW"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "UTS Challenge Studio Demo"),
            x509.NameAttribute(NameOID.COMMON_NAME, common_name),
        ]
    )


def create_certificate(
    filename: str,
    common_name: str,
    days_valid: int,
    key_size: int = 2048,
    hash_algo=hashes.SHA256(),
    self_signed: bool = True,
    not_before_offset_days: int = 0,
) -> None:
    key = rsa.generate_private_key(public_exponent=65537, key_size=key_size)
    subject = issuer = _build_name(common_name)

    now = dt.datetime.now(dt.timezone.utc)
    not_before = now + dt.timedelta(days=not_before_offset_days)
    not_after = not_before + dt.timedelta(days=days_valid)

    builder = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(not_before)
        .not_valid_after(not_after)
        .add_extension(
            x509.SubjectAlternativeName([x509.DNSName(common_name)]),
            critical=False,
        )
        .add_extension(
            x509.BasicConstraints(ca=False, path_length=None),
            critical=True,
        )
    )

    cert = builder.sign(key, hash_algo)

    pem_path = SAMPLES_DIR / filename
    pem_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    print(f"Created {pem_path}  (valid {not_before.date()} → {not_after.date()})")


def main() -> None:
    print("Generating sample certificates…")

    # 1. Healthy long-lived certificate
    create_certificate(
        "valid_long.pem",
        "app.valid-demo.local",
        days_valid=365,
        key_size=2048,
    )

    # 2. Near-expiry (within typical warning window)
    create_certificate(
        "near_expiry.pem",
        "api.near-expiry.local",
        days_valid=12,
        key_size=2048,
    )

    # 3. Already expired
    create_certificate(
        "expired.pem",
        "legacy.expired.local",
        days_valid=30,
        key_size=2048,
        not_before_offset_days=-60,  # started 60 days ago, valid 30 days → expired 30 days ago
    )

    # 4. Weak cryptography (small 1024-bit key – still triggers min_key_size rule)
    create_certificate(
        "weak_crypto.pem",
        "old.weak-crypto.local",
        days_valid=90,
        key_size=1024,
        hash_algo=hashes.SHA256(),
    )

    # 5. Self-signed with no SAN (will trigger medium findings)
    # We deliberately omit the SAN extension here
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = _build_name("selfsigned.no-san.local")
    now = dt.datetime.now(dt.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + dt.timedelta(days=180))
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .sign(key, hashes.SHA256())
    )
    path = SAMPLES_DIR / "selfsigned_no_san.pem"
    path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    print(f"Created {path}")

    print("\nDone. Sample certificates are ready in the samples/ directory.")


if __name__ == "__main__":
    main()
